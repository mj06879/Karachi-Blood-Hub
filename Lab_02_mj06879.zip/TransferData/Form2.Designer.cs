﻿
namespace TransferData
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.isbn_cd = new System.Windows.Forms.Label();
            this.title_cd = new System.Windows.Forms.Label();
            this.purchased_on_cd = new System.Windows.Forms.Label();
            this.category_cd = new System.Windows.Forms.Label();
            this.sub_cat_cd = new System.Windows.Forms.Label();
            this.isbn_tb = new System.Windows.Forms.TextBox();
            this.title_tb = new System.Windows.Forms.TextBox();
            this.dtp_purchased_on = new System.Windows.Forms.DateTimePicker();
            this.cat_cb = new System.Windows.Forms.ComboBox();
            this.sub_cat_cb = new System.Windows.Forms.ComboBox();
            this.author_gb = new System.Windows.Forms.GroupBox();
            this.author_name_cd = new System.Windows.Forms.Label();
            this.author_name_tb = new System.Windows.Forms.TextBox();
            this.author_lb = new System.Windows.Forms.ListBox();
            this.add_b = new System.Windows.Forms.Button();
            this.type_gb = new System.Windows.Forms.GroupBox();
            this.refrence_book_rb = new System.Windows.Forms.RadioButton();
            this.text_book_rb = new System.Windows.Forms.RadioButton();
            this.journal_rb = new System.Windows.Forms.RadioButton();
            this.issuance_gb = new System.Windows.Forms.GroupBox();
            this.issue_date_cd = new System.Windows.Forms.Label();
            this.issued_to_cd = new System.Windows.Forms.Label();
            this.issued_to_tb = new System.Windows.Forms.TextBox();
            this.issue_date_dtp = new System.Windows.Forms.DateTimePicker();
            this.issued_check_b = new System.Windows.Forms.CheckBox();
            this.ok_b = new System.Windows.Forms.Button();
            this.close_b = new System.Windows.Forms.Button();
            this.author_gb.SuspendLayout();
            this.type_gb.SuspendLayout();
            this.issuance_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // isbn_cd
            // 
            this.isbn_cd.AutoSize = true;
            this.isbn_cd.Location = new System.Drawing.Point(53, 50);
            this.isbn_cd.Name = "isbn_cd";
            this.isbn_cd.Size = new System.Drawing.Size(51, 20);
            this.isbn_cd.TabIndex = 0;
            this.isbn_cd.Text = "ISBN:";
            this.isbn_cd.Click += new System.EventHandler(this.label1_Click);
            // 
            // title_cd
            // 
            this.title_cd.AutoSize = true;
            this.title_cd.Location = new System.Drawing.Point(53, 95);
            this.title_cd.Name = "title_cd";
            this.title_cd.Size = new System.Drawing.Size(42, 20);
            this.title_cd.TabIndex = 1;
            this.title_cd.Text = "Title:";
            // 
            // purchased_on_cd
            // 
            this.purchased_on_cd.AutoSize = true;
            this.purchased_on_cd.Location = new System.Drawing.Point(53, 143);
            this.purchased_on_cd.Name = "purchased_on_cd";
            this.purchased_on_cd.Size = new System.Drawing.Size(114, 20);
            this.purchased_on_cd.TabIndex = 2;
            this.purchased_on_cd.Text = "Purchased On:";
            // 
            // category_cd
            // 
            this.category_cd.AutoSize = true;
            this.category_cd.Location = new System.Drawing.Point(53, 187);
            this.category_cd.Name = "category_cd";
            this.category_cd.Size = new System.Drawing.Size(110, 30);
            this.category_cd.TabIndex = 3;
            this.category_cd.Text = "Category";
            // 
            // sub_cat_cd
            // 
            this.sub_cat_cd.AutoSize = true;
            this.sub_cat_cd.Location = new System.Drawing.Point(53, 240);
            this.sub_cat_cd.Name = "sub_cat_cd";
            this.sub_cat_cd.Size = new System.Drawing.Size(159, 30);
            this.sub_cat_cd.TabIndex = 4;
            this.sub_cat_cd.Text = "Sub Category";
            // 
            // isbn_tb
            // 
            this.isbn_tb.Location = new System.Drawing.Point(254, 50);
            this.isbn_tb.Name = "isbn_tb";
            this.isbn_tb.Size = new System.Drawing.Size(193, 26);
            this.isbn_tb.TabIndex = 5;
            // 
            // title_tb
            // 
            this.title_tb.Location = new System.Drawing.Point(254, 95);
            this.title_tb.Name = "title_tb";
            this.title_tb.Size = new System.Drawing.Size(322, 26);
            this.title_tb.TabIndex = 6;
            // 
            // dtp_purchased_on
            // 
            this.dtp_purchased_on.Location = new System.Drawing.Point(254, 143);
            this.dtp_purchased_on.Name = "dtp_purchased_on";
            this.dtp_purchased_on.Size = new System.Drawing.Size(322, 26);
            this.dtp_purchased_on.TabIndex = 7;
            // 
            // cat_cb
            // 
            this.cat_cb.FormattingEnabled = true;
            this.cat_cb.Location = new System.Drawing.Point(254, 189);
            this.cat_cb.Name = "cat_cb";
            this.cat_cb.Size = new System.Drawing.Size(329, 28);
            this.cat_cb.TabIndex = 8;
            // 
            // sub_cat_cb
            // 
            this.sub_cat_cb.FormattingEnabled = true;
            this.sub_cat_cb.Location = new System.Drawing.Point(254, 242);
            this.sub_cat_cb.Name = "sub_cat_cb";
            this.sub_cat_cb.Size = new System.Drawing.Size(329, 28);
            this.sub_cat_cb.TabIndex = 9;
            // 
            // author_gb
            // 
            this.author_gb.Controls.Add(this.add_b);
            this.author_gb.Controls.Add(this.author_lb);
            this.author_gb.Controls.Add(this.author_name_tb);
            this.author_gb.Controls.Add(this.author_name_cd);
            this.author_gb.Location = new System.Drawing.Point(57, 318);
            this.author_gb.Name = "author_gb";
            this.author_gb.Size = new System.Drawing.Size(526, 309);
            this.author_gb.TabIndex = 10;
            this.author_gb.TabStop = false;
            this.author_gb.Text = "Authors";
            // 
            // author_name_cd
            // 
            this.author_name_cd.AutoSize = true;
            this.author_name_cd.Location = new System.Drawing.Point(6, 47);
            this.author_name_cd.Name = "author_name_cd";
            this.author_name_cd.Size = new System.Drawing.Size(161, 30);
            this.author_name_cd.TabIndex = 11;
            this.author_name_cd.Text = "Author Name:";
            // 
            // author_name_tb
            // 
            this.author_name_tb.Location = new System.Drawing.Point(173, 44);
            this.author_name_tb.Name = "author_name_tb";
            this.author_name_tb.Size = new System.Drawing.Size(234, 26);
            this.author_name_tb.TabIndex = 11;
            // 
            // author_lb
            // 
            this.author_lb.FormattingEnabled = true;
            this.author_lb.ItemHeight = 20;
            this.author_lb.Location = new System.Drawing.Point(173, 85);
            this.author_lb.Name = "author_lb";
            this.author_lb.Size = new System.Drawing.Size(234, 184);
            this.author_lb.TabIndex = 12;
            // 
            // add_b
            // 
            this.add_b.Location = new System.Drawing.Point(417, 42);
            this.add_b.Name = "add_b";
            this.add_b.Size = new System.Drawing.Size(102, 35);
            this.add_b.TabIndex = 13;
            this.add_b.Text = "Add";
            this.add_b.UseVisualStyleBackColor = true;
            // 
            // type_gb
            // 
            this.type_gb.Controls.Add(this.journal_rb);
            this.type_gb.Controls.Add(this.text_book_rb);
            this.type_gb.Controls.Add(this.refrence_book_rb);
            this.type_gb.Location = new System.Drawing.Point(57, 633);
            this.type_gb.Name = "type_gb";
            this.type_gb.Size = new System.Drawing.Size(216, 184);
            this.type_gb.TabIndex = 11;
            this.type_gb.TabStop = false;
            this.type_gb.Text = "Type";
            // 
            // refrence_book_rb
            // 
            this.refrence_book_rb.AutoSize = true;
            this.refrence_book_rb.Location = new System.Drawing.Point(29, 40);
            this.refrence_book_rb.Name = "refrence_book_rb";
            this.refrence_book_rb.Size = new System.Drawing.Size(150, 24);
            this.refrence_book_rb.TabIndex = 12;
            this.refrence_book_rb.TabStop = true;
            this.refrence_book_rb.Text = "Reference Book";
            this.refrence_book_rb.UseVisualStyleBackColor = true;
            // 
            // text_book_rb
            // 
            this.text_book_rb.AutoSize = true;
            this.text_book_rb.Location = new System.Drawing.Point(29, 80);
            this.text_book_rb.Name = "text_book_rb";
            this.text_book_rb.Size = new System.Drawing.Size(105, 24);
            this.text_book_rb.TabIndex = 13;
            this.text_book_rb.TabStop = true;
            this.text_book_rb.Text = "Text Book";
            this.text_book_rb.UseVisualStyleBackColor = true;
            // 
            // journal_rb
            // 
            this.journal_rb.AutoSize = true;
            this.journal_rb.Location = new System.Drawing.Point(29, 128);
            this.journal_rb.Name = "journal_rb";
            this.journal_rb.Size = new System.Drawing.Size(86, 24);
            this.journal_rb.TabIndex = 14;
            this.journal_rb.TabStop = true;
            this.journal_rb.Text = "Journal";
            this.journal_rb.UseVisualStyleBackColor = true;
            // 
            // issuance_gb
            // 
            this.issuance_gb.Controls.Add(this.issued_check_b);
            this.issuance_gb.Controls.Add(this.issued_to_tb);
            this.issuance_gb.Controls.Add(this.issue_date_cd);
            this.issuance_gb.Controls.Add(this.issued_to_cd);
            this.issuance_gb.Location = new System.Drawing.Point(295, 633);
            this.issuance_gb.Name = "issuance_gb";
            this.issuance_gb.Size = new System.Drawing.Size(288, 184);
            this.issuance_gb.TabIndex = 12;
            this.issuance_gb.TabStop = false;
            this.issuance_gb.Text = "Issuance";
            // 
            // issue_date_cd
            // 
            this.issue_date_cd.AutoSize = true;
            this.issue_date_cd.Location = new System.Drawing.Point(6, 128);
            this.issue_date_cd.Name = "issue_date_cd";
            this.issue_date_cd.Size = new System.Drawing.Size(137, 30);
            this.issue_date_cd.TabIndex = 13;
            this.issue_date_cd.Text = "Issue Date:";
            // 
            // issued_to_cd
            // 
            this.issued_to_cd.AutoSize = true;
            this.issued_to_cd.Location = new System.Drawing.Point(6, 84);
            this.issued_to_cd.Name = "issued_to_cd";
            this.issued_to_cd.Size = new System.Drawing.Size(119, 30);
            this.issued_to_cd.TabIndex = 14;
            this.issued_to_cd.Text = "Issued to:";
            // 
            // issued_to_tb
            // 
            this.issued_to_tb.Location = new System.Drawing.Point(123, 79);
            this.issued_to_tb.Name = "issued_to_tb";
            this.issued_to_tb.Size = new System.Drawing.Size(159, 26);
            this.issued_to_tb.TabIndex = 13;
            // 
            // issue_date_dtp
            // 
            this.issue_date_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.issue_date_dtp.Location = new System.Drawing.Point(411, 721);
            this.issue_date_dtp.Name = "issue_date_dtp";
            this.issue_date_dtp.Size = new System.Drawing.Size(159, 26);
            this.issue_date_dtp.TabIndex = 13;
            // 
            // issued_check_b
            // 
            this.issued_check_b.AutoSize = true;
            this.issued_check_b.Location = new System.Drawing.Point(30, 40);
            this.issued_check_b.Name = "issued_check_b";
            this.issued_check_b.Size = new System.Drawing.Size(125, 36);
            this.issued_check_b.TabIndex = 14;
            this.issued_check_b.Text = "Issued";
            this.issued_check_b.UseVisualStyleBackColor = true;
            // 
            // ok_b
            // 
            this.ok_b.Location = new System.Drawing.Point(411, 843);
            this.ok_b.Name = "ok_b";
            this.ok_b.Size = new System.Drawing.Size(114, 40);
            this.ok_b.TabIndex = 14;
            this.ok_b.Text = "OK";
            this.ok_b.UseVisualStyleBackColor = true;
            // 
            // close_b
            // 
            this.close_b.Location = new System.Drawing.Point(531, 843);
            this.close_b.Name = "close_b";
            this.close_b.Size = new System.Drawing.Size(114, 40);
            this.close_b.TabIndex = 15;
            this.close_b.Text = "Close";
            this.close_b.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 930);
            this.Controls.Add(this.close_b);
            this.Controls.Add(this.ok_b);
            this.Controls.Add(this.issue_date_dtp);
            this.Controls.Add(this.issuance_gb);
            this.Controls.Add(this.type_gb);
            this.Controls.Add(this.author_gb);
            this.Controls.Add(this.sub_cat_cb);
            this.Controls.Add(this.cat_cb);
            this.Controls.Add(this.dtp_purchased_on);
            this.Controls.Add(this.title_tb);
            this.Controls.Add(this.isbn_tb);
            this.Controls.Add(this.sub_cat_cd);
            this.Controls.Add(this.category_cd);
            this.Controls.Add(this.purchased_on_cd);
            this.Controls.Add(this.title_cd);
            this.Controls.Add(this.isbn_cd);
            this.Name = "Form2";
            this.Text = "View Form";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.author_gb.ResumeLayout(false);
            this.author_gb.PerformLayout();
            this.type_gb.ResumeLayout(false);
            this.type_gb.PerformLayout();
            this.issuance_gb.ResumeLayout(false);
            this.issuance_gb.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label isbn_cd;
        private System.Windows.Forms.Label title_cd;
        private System.Windows.Forms.Label purchased_on_cd;
        private System.Windows.Forms.Label category_cd;
        private System.Windows.Forms.Label sub_cat_cd;
        private System.Windows.Forms.TextBox isbn_tb;
        private System.Windows.Forms.TextBox title_tb;
        private System.Windows.Forms.DateTimePicker dtp_purchased_on;
        private System.Windows.Forms.ComboBox cat_cb;
        private System.Windows.Forms.ComboBox sub_cat_cb;
        private System.Windows.Forms.GroupBox author_gb;
        private System.Windows.Forms.Button add_b;
        private System.Windows.Forms.ListBox author_lb;
        private System.Windows.Forms.TextBox author_name_tb;
        private System.Windows.Forms.Label author_name_cd;
        private System.Windows.Forms.GroupBox type_gb;
        private System.Windows.Forms.RadioButton journal_rb;
        private System.Windows.Forms.RadioButton text_book_rb;
        private System.Windows.Forms.RadioButton refrence_book_rb;
        private System.Windows.Forms.GroupBox issuance_gb;
        private System.Windows.Forms.TextBox issued_to_tb;
        private System.Windows.Forms.Label issue_date_cd;
        private System.Windows.Forms.Label issued_to_cd;
        private System.Windows.Forms.DateTimePicker issue_date_dtp;
        private System.Windows.Forms.CheckBox issued_check_b;
        private System.Windows.Forms.Button ok_b;
        private System.Windows.Forms.Button close_b;
    }
}