﻿
namespace TransferData
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.search_gb = new System.Windows.Forms.GroupBox();
            this.search_b = new System.Windows.Forms.Button();
            this.type_gb = new System.Windows.Forms.GroupBox();
            this.journal_rb = new System.Windows.Forms.RadioButton();
            this.text_book_rb = new System.Windows.Forms.RadioButton();
            this.reference_book_rb = new System.Windows.Forms.RadioButton();
            this.title_tb = new System.Windows.Forms.TextBox();
            this.category_cb = new System.Windows.Forms.ComboBox();
            this.title_cd = new System.Windows.Forms.Label();
            this.category_cd = new System.Windows.Forms.Label();
            this.results_lb = new System.Windows.Forms.ListBox();
            this.results_gb = new System.Windows.Forms.GroupBox();
            this.view_b = new System.Windows.Forms.Button();
            this.delete_b = new System.Windows.Forms.Button();
            this.close_b = new System.Windows.Forms.Button();
            this.search_gb.SuspendLayout();
            this.type_gb.SuspendLayout();
            this.results_gb.SuspendLayout();
            this.SuspendLayout();
            // 
            // search_gb
            // 
            this.search_gb.Controls.Add(this.search_b);
            this.search_gb.Controls.Add(this.type_gb);
            this.search_gb.Controls.Add(this.title_tb);
            this.search_gb.Controls.Add(this.category_cb);
            this.search_gb.Controls.Add(this.title_cd);
            this.search_gb.Controls.Add(this.category_cd);
            this.search_gb.Location = new System.Drawing.Point(30, 22);
            this.search_gb.Name = "search_gb";
            this.search_gb.Size = new System.Drawing.Size(697, 219);
            this.search_gb.TabIndex = 0;
            this.search_gb.TabStop = false;
            this.search_gb.Text = "Search";
            // 
            // search_b
            // 
            this.search_b.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.search_b.Location = new System.Drawing.Point(556, 166);
            this.search_b.Name = "search_b";
            this.search_b.Size = new System.Drawing.Size(114, 36);
            this.search_b.TabIndex = 6;
            this.search_b.Text = "Search";
            this.search_b.UseVisualStyleBackColor = true;
            this.search_b.Click += new System.EventHandler(this.search_b_Click);
            // 
            // type_gb
            // 
            this.type_gb.Controls.Add(this.journal_rb);
            this.type_gb.Controls.Add(this.text_book_rb);
            this.type_gb.Controls.Add(this.reference_book_rb);
            this.type_gb.Location = new System.Drawing.Point(475, 25);
            this.type_gb.Name = "type_gb";
            this.type_gb.Size = new System.Drawing.Size(195, 135);
            this.type_gb.TabIndex = 4;
            this.type_gb.TabStop = false;
            this.type_gb.Text = "Type";
            // 
            // journal_rb
            // 
            this.journal_rb.AutoSize = true;
            this.journal_rb.Location = new System.Drawing.Point(27, 102);
            this.journal_rb.Name = "journal_rb";
            this.journal_rb.Size = new System.Drawing.Size(86, 24);
            this.journal_rb.TabIndex = 7;
            this.journal_rb.TabStop = true;
            this.journal_rb.Text = "Journal";
            this.journal_rb.UseVisualStyleBackColor = true;
            // 
            // text_book_rb
            // 
            this.text_book_rb.AutoSize = true;
            this.text_book_rb.Location = new System.Drawing.Point(27, 72);
            this.text_book_rb.Name = "text_book_rb";
            this.text_book_rb.Size = new System.Drawing.Size(103, 24);
            this.text_book_rb.TabIndex = 6;
            this.text_book_rb.TabStop = true;
            this.text_book_rb.Text = "Text book";
            this.text_book_rb.UseVisualStyleBackColor = true;
            this.text_book_rb.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // reference_book_rb
            // 
            this.reference_book_rb.AutoSize = true;
            this.reference_book_rb.Location = new System.Drawing.Point(27, 42);
            this.reference_book_rb.Name = "reference_book_rb";
            this.reference_book_rb.Size = new System.Drawing.Size(148, 24);
            this.reference_book_rb.TabIndex = 5;
            this.reference_book_rb.TabStop = true;
            this.reference_book_rb.Text = "Reference book";
            this.reference_book_rb.UseVisualStyleBackColor = true;
            this.reference_book_rb.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // title_tb
            // 
            this.title_tb.Location = new System.Drawing.Point(122, 91);
            this.title_tb.Name = "title_tb";
            this.title_tb.Size = new System.Drawing.Size(326, 26);
            this.title_tb.TabIndex = 3;
            // 
            // category_cb
            // 
            this.category_cb.FormattingEnabled = true;
            this.category_cb.Location = new System.Drawing.Point(122, 43);
            this.category_cb.Name = "category_cb";
            this.category_cb.Size = new System.Drawing.Size(173, 28);
            this.category_cb.TabIndex = 2;
            // 
            // title_cd
            // 
            this.title_cd.AutoSize = true;
            this.title_cd.Location = new System.Drawing.Point(6, 91);
            this.title_cd.Name = "title_cd";
            this.title_cd.Size = new System.Drawing.Size(42, 20);
            this.title_cd.TabIndex = 1;
            this.title_cd.Text = "Title:";
            // 
            // category_cd
            // 
            this.category_cd.AutoSize = true;
            this.category_cd.Location = new System.Drawing.Point(6, 43);
            this.category_cd.Name = "category_cd";
            this.category_cd.Size = new System.Drawing.Size(77, 20);
            this.category_cd.TabIndex = 0;
            this.category_cd.Text = "Category:";
            // 
            // results_lb
            // 
            this.results_lb.FormattingEnabled = true;
            this.results_lb.ItemHeight = 20;
            this.results_lb.Location = new System.Drawing.Point(10, 40);
            this.results_lb.Name = "results_lb";
            this.results_lb.Size = new System.Drawing.Size(660, 344);
            this.results_lb.TabIndex = 1;
            this.results_lb.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // results_gb
            // 
            this.results_gb.Controls.Add(this.results_lb);
            this.results_gb.Location = new System.Drawing.Point(30, 247);
            this.results_gb.Name = "results_gb";
            this.results_gb.Size = new System.Drawing.Size(697, 424);
            this.results_gb.TabIndex = 2;
            this.results_gb.TabStop = false;
            this.results_gb.Text = "Results";
            // 
            // view_b
            // 
            this.view_b.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.view_b.Location = new System.Drawing.Point(483, 677);
            this.view_b.Name = "view_b";
            this.view_b.Size = new System.Drawing.Size(114, 38);
            this.view_b.TabIndex = 3;
            this.view_b.Text = "View";
            this.view_b.UseVisualStyleBackColor = true;
            this.view_b.Click += new System.EventHandler(this.view_b_Click);
            // 
            // delete_b
            // 
            this.delete_b.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.delete_b.Location = new System.Drawing.Point(613, 677);
            this.delete_b.Name = "delete_b";
            this.delete_b.Size = new System.Drawing.Size(114, 38);
            this.delete_b.TabIndex = 4;
            this.delete_b.Text = "Delete";
            this.delete_b.UseVisualStyleBackColor = true;
            this.delete_b.Click += new System.EventHandler(this.delete_b_Click);
            // 
            // close_b
            // 
            this.close_b.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.close_b.Location = new System.Drawing.Point(613, 730);
            this.close_b.Name = "close_b";
            this.close_b.Size = new System.Drawing.Size(114, 38);
            this.close_b.TabIndex = 5;
            this.close_b.Text = "Close";
            this.close_b.UseVisualStyleBackColor = true;
            this.close_b.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 791);
            this.Controls.Add(this.close_b);
            this.Controls.Add(this.delete_b);
            this.Controls.Add(this.view_b);
            this.Controls.Add(this.results_gb);
            this.Controls.Add(this.search_gb);
            this.Name = "Form1";
            this.Text = "Book Search";
            this.search_gb.ResumeLayout(false);
            this.search_gb.PerformLayout();
            this.type_gb.ResumeLayout(false);
            this.type_gb.PerformLayout();
            this.results_gb.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox search_gb;
        private System.Windows.Forms.RadioButton reference_book_rb;
        private System.Windows.Forms.GroupBox type_gb;
        private System.Windows.Forms.TextBox title_tb;
        private System.Windows.Forms.ComboBox category_cb;
        private System.Windows.Forms.Label title_cd;
        private System.Windows.Forms.Label category_cd;
        private System.Windows.Forms.RadioButton journal_rb;
        private System.Windows.Forms.RadioButton text_book_rb;
        private System.Windows.Forms.ListBox results_lb;
        private System.Windows.Forms.GroupBox results_gb;
        private System.Windows.Forms.Button view_b;
        private System.Windows.Forms.Button delete_b;
        private System.Windows.Forms.Button close_b;
        private System.Windows.Forms.Button search_b;
    }
}

