﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransferData
{
    public partial class Form1 : Form
    {
        public class Book
        {
            public string ISBN;
            public string Title;
            public int catIndex;
            public int subcatIndex;
            public string authors;
            public DateTime purchasedon;
            public int type;
            public bool isIssued;
            public string issuedTo;
            public DateTime issuedOn;

            public Book(string _ISBN, string _title, int _cat, int _subcat, string _authors, DateTime _purchasedOn, int _type, bool _isIssued, string _issuedTo, DateTime _issuedDate)
            {
                ISBN = _ISBN;
                Title = _title;
                catIndex = _cat;
                subcatIndex = _subcat;
                authors = _authors;
                purchasedon = _purchasedOn;
                type = _type;
                isIssued = _isIssued;
                issuedTo = _issuedTo;
                issuedOn = _issuedDate;

            }
        }
        List<Book> books = new List<Book>();

        public Form1()
        {
            InitializeComponent();
            // Code to be copied in the Form2 Constructor
            this.category_cb.Items.Add("Database Systems");
            this.category_cb.Items.Add("OOP");
            this.category_cb.Items.Add("Artificial Intelligence");

            books.Add(new Book("0201144719 9780201144710", "An introduction to database systems", 1, 1, "C J Date", Convert.ToDateTime("1 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0805301453 9780805301458", "Fundamentals of database systems", 1, 1, "Ramez Elmasri; Sham Navathe", Convert.ToDateTime("10 jan 2015"), 2, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("1571690867 9781571690869", "Object oriented programming in Java", 2, 2, "Stephen Gilbert; Bill McCarty", Convert.ToDateTime("15 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("1842652478 9781842652473", "Object oriented programming using C++", 2, 1, "B Chandra", Convert.ToDateTime("16 jan 2015"), 2, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0070522618 9780070522619", "Artificial intelligence", 3, 2, "Elaine Rich", Convert.ToDateTime("20 jan 2015"), 1, false, "", Convert.ToDateTime("30 Nov 2015")));
            books.Add(new Book("0865760047 9780865760042", "The Handbook of artificial intelligence", 3, 2, "Avron Barr; Edward A Feigenbaum; Paul R Cohen", Convert.ToDateTime("22 jan 2015"), 2, false, "", Convert.ToDateTime("30 Nov 2015")));
            foreach (Book b in books)
            {
                // results_lb.Items.Clear();
                if (b.catIndex == 1)
                {
                    results_lb.Items.Add(b.ISBN + "/" + "Database Systems" + "/" + b.Title);
                }
                else if (b.catIndex == 2)
                {
                    results_lb.Items.Add(b.ISBN + "/" + "OOP" + "/" + b.Title);
                }
                else
                {
                    results_lb.Items.Add(b.ISBN + "/" + "Artificial Intelligence " + "/" + b.Title);
                }
            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void search_b_Click(object sender, EventArgs e)
        {
            results_lb.Items.Clear();
            int t = 0;
            if (category_cb.SelectedIndex == 0) { t = 1; }
            else if (category_cb.SelectedIndex == 1) { t = 2; }
            else if (category_cb.SelectedIndex == 2) { t = 3; }
            int rb = 0;
            if (reference_book_rb.Checked) { rb = 1; }
            else if (text_book_rb.Checked) { rb = 2; }
            else if (journal_rb.Checked) { rb = 3; }

            foreach (Book b in books)
            {
                if (b.Title.ToLower().Contains(title_tb.Text.ToLower()) && (b.catIndex == t) && (b.type == rb) &&
                    (b.catIndex == t))
                {
                    if (b.catIndex == 1)
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "Database Systems" + "/" + b.Title);
                    }
                    else if (b.catIndex == 2)
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "OOP" + "/" + b.Title);
                    }
                    else
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "Artificial Intelligence " + "/" + b.Title);
                    }
                }
            }

        }

        private void delete_b_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Do you want to delete?", "Confirmation", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
            {
                // get the selected book
                string selectedBook = results_lb.SelectedItem.ToString();
                // parse to get ISBN number
                // split by / sighn
                string[] parts = selectedBook.Split(new char[] { '/' });
                // first part is ISBN
                string isbn = parts[0];
                // iterate books collection to find the book to be removed
                for (int i = 0; i < books.Count(); i++)
                {
                    // check if ISBN of the book is same as isbn of selected book
                    if (books[i].ISBN == isbn)
                    {
                        books.RemoveAt(i);
                    }
                }
                // repopulate the listbox
                results_lb.Items.Clear();
                foreach (Book b in books)
                {
                    // results_lb.Items.Clear();
                    if (b.catIndex == 1)
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "Database Systems" + "/" + b.Title);
                    }
                    else if (b.catIndex == 2)
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "OOP" + "/" + b.Title);
                    }
                    else
                    {
                        results_lb.Items.Add(b.ISBN + "/" + "Artificial Intelligence " + "/" + b.Title);
                    }
                }
            }
        }

        private void view_b_Click(object sender, EventArgs e)
        {
            // get the selected book
            string selectedBook = results_lb.SelectedItem.ToString();
            // parse to get ISBN number
            // split by / sighn
            string[] parts = selectedBook.Split(new char[] { '/' });
            // first part is ISBN
            string isbn = parts[0];

            Book required;
            for (int i = 0; i < books.Count(); i++)
            {
                // check if ISBN of the book is same as isbn of selected book
                if (books[i].ISBN == isbn)
                {
                    required = books[i];
                    Form2 view = new Form2();
                    view.stdISBN = parts[0];
                    view.stdTitle = parts[1];
                    view.stdPurOn = required.purchasedon;
                    view.stdCat = required.catIndex;
                    view.stdSubcat = required.subcatIndex;
                    //string cat = "";
                    //List<string> sub_cat = new List<string>;

                    //view.stdCat = cat;
                    //view.stdSubcat = parts[3];
                    //view.stdAthr_lb = required.authors;
                    view.stdAthr_lb = required.authors.Split(new char[] { ';' });

                    view.stdType = required.type;
                    view.stdIssued = required.isIssued;
                    view.stdIssue_to = required.issuedTo;
                    view.stdIssued_at = required.issuedOn;
                    view.ShowDialog();
                    break;
                }
            }
            
            
        }
    }
}

