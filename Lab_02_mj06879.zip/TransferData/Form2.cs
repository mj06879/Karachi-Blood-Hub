﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransferData
{
    public partial class Form2 : Form
    {
        public string stdISBN { get; set; }
        public string stdTitle { get; set; }
        public int stdCat { get; set; }
        public int stdSubcat { get; set; }
        public string[] stdAthr_lb { get; set; }
        public DateTime stdPurOn { get; set; }
        public int stdType { get; set; }
        public string stdIssue_to { get; set; }
        public bool stdIssued { get; set; }

        public DateTime stdIssued_at { get; set; }

        public Form2()
        {
            InitializeComponent();
            isbn_tb.Enabled = false;
            title_tb.Enabled = false;
            cat_cb.Enabled = false;
            sub_cat_cb.Enabled = false;
            author_name_tb.Enabled = false;
            author_lb.Enabled = false;
            refrence_book_rb.Enabled = false;
            text_book_rb.Enabled = false;
            journal_rb.Enabled = false;
            issued_check_b.Enabled = false;
            issued_to_tb.Enabled = false;
            issue_date_dtp.Enabled = false;
            add_b.Enabled = false;
            dtp_purchased_on.Enabled = false;
            ok_b.Enabled = false;
            close_b.Enabled = false;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            isbn_tb.Text = stdISBN;
            title_tb.Text = stdTitle;
            dtp_purchased_on.Value = stdPurOn;

            foreach (string i in stdAthr_lb)
            {
                author_lb.Items.Add(i);
            }
            //author_lb.Items.Add(stdAthr_lb);

            
            switch (stdCat)
            {
                case 1:
                    cat_cb.Items.Add("Database Systems");
                    //sub_cat = List["ERD", "SQL", "OLAP", "Data Mining"];
                    if (stdSubcat == 1) { sub_cat_cb.Items.Add("ERD"); }
                    else if (stdSubcat == 2) { sub_cat_cb.Items.Add("SQL"); }
                    else if (stdSubcat == 3) { sub_cat_cb.Items.Add("OLAP"); }
                    else if (stdSubcat == 4) { sub_cat_cb.Items.Add("Data Mining"); }
                    break;
                case 2:
                    cat_cb.Items.Add("OOP");
                    if (stdSubcat == 1) { sub_cat_cb.Items.Add("C++"); }
                    else if (stdSubcat == 2) { sub_cat_cb.Items.Add("Java"); }
                    break;
                case 3:
                    cat_cb.Items.Add("Artificial Intelligence");
                    if (stdSubcat == 1) { sub_cat_cb.Items.Add("Mahcine Learning"); }
                    else if (stdSubcat == 2) { sub_cat_cb.Items.Add("Robotics"); }
                    else if (stdSubcat == 3) { sub_cat_cb.Items.Add("Computer Vision"); }
                    break;
                default:
                    break;
            }
            this.cat_cb.Text = this.cat_cb.Items[0].ToString();
            this.sub_cat_cb.Text = this.sub_cat_cb.Items[0].ToString();

            switch (stdType)
            {
                case 1:
                    refrence_book_rb.Checked = true;
                    break;
                case 2:
                    text_book_rb.Checked = true;
                    break;
                case 3:
                    journal_rb.Checked = true;
                    break;
                default:
                    break;
            }
            issued_check_b.Checked = stdIssued;
            issued_to_tb.Text = stdIssue_to;
            issue_date_dtp.Value = stdIssued_at;
        }
    }
}
