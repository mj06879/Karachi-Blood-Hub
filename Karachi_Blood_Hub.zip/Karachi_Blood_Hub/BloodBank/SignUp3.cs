﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BloodBank
{
    public partial class SignUp3 : Form
    {
        public SignUp3()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            SignUp s1 = new SignUp();
            s1.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            SignUp2 s2 = new SignUp2();
            s2.Show();
            this.Hide();
        }

        private void closebtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SignUp s1 = new SignUp();
            s1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignUp2 s2 = new SignUp2();
            s2.Show();
            this.Hide();
        }

        private void closebtn_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }

        private void closebtn_Click_2(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SignUp3_Load(object sender, EventArgs e)
        {

        }
    }
}
